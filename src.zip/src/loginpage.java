import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class loginpage extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					loginpage frame = new loginpage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public loginpage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUsername = new JLabel("Username:");
		lblUsername.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblUsername.setBounds(76, 61, 82, 14);
		contentPane.add(lblUsername);
		
		JLabel lblPassword = new JLabel("password:");
		lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblPassword.setBounds(76, 111, 82, 14);
		contentPane.add(lblPassword);
		
		textField = new JTextField();
		textField.setBounds(168, 56, 151, 27);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblForgotPassword = new JLabel("forgot password");
		lblForgotPassword.setBounds(126, 155, 94, 14);
		contentPane.add(lblForgotPassword);
		
		final JButton btnSubmit = new JButton("SUBMIT");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					String u=textField.getText();
					String p=textField_1.getText();
					
					String str="select * from tb5 where name_1='"+u+"' OR pass='"+p+"'";
					Class.forName("org.h2.Driver");
					Connection conn=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test","sa","");
					Statement stm=conn.createStatement();
					ResultSet rs=stm.executeQuery(str);
					rs.next();
					String usname=rs.getString(1);
					String pass2=rs.getString(2);
					if((u.equals(usname))&&(p.equals(pass2)))
					{
						JOptionPane.showMessageDialog(btnSubmit, "LoginSucess!!");
						new accountdetails().setVisible(true);
					}
					else
					{
						//JOptionPane.showMessageDialog(btnSubmit, "LoginFail!!");
					}
				}
				catch(Exception t)
				{
					System.out.println(t);
					JOptionPane.showMessageDialog(btnSubmit, "LoginFail!!");
				}
			}
		});
		btnSubmit.setBounds(114, 192, 116, 23);
		contentPane.add(btnSubmit);
		
		textField_1 = new JTextField();
		textField_1.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent e) {
			}
		});
		textField_1.setBounds(168, 109, 151, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
	}
}
