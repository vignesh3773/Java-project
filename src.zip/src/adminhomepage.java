import java.awt.BorderLayout;
import java.awt.EventQueue;
//import java.awt.ScrollPane;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JButton;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;

public class adminhomepage extends JFrame {
	
	private JPanel contentPane;
	private JTable table_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args)
	{
		EventQueue.invokeLater(new Runnable() 
		{
			public void run()
			{
				try 
				{
					adminhomepage frame = new adminhomepage();
					frame.setVisible(true);
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
	
	}
	public adminhomepage()
	{
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 754, 362);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		getContentPane().setLayout(null);
		
		JButton btnViewUserDatabase = new JButton("View User Database");
		btnViewUserDatabase.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					String qstr="select * from tb4";
					Class.forName("org.h2.Driver");
					Connection conn=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test","sa","");
					Statement stm=conn.createStatement();
					
					ResultSet rs=stm.executeQuery(qstr);
					table_1.setModel(DbUtils.resultSetToTableModel(rs));
					
				}
				catch(Exception t)
				{
					System.out.println(t);
				}
			}
		});
		btnViewUserDatabase.setBounds(10, 44, 181, 23);
		contentPane.add(btnViewUserDatabase);
		
		JButton btnViewUsuserDetails = new JButton("Access user detail");
		btnViewUsuserDetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new useraccessdetails().setVisible(true);
			}
		});
		btnViewUsuserDetails.setBounds(235, 44, 189, 23);
		contentPane.add(btnViewUsuserDetails);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 95, 739, 216);
		contentPane.add(scrollPane);
		
		table_1 = new JTable();
		scrollPane.setViewportView(table_1);
	}
}

