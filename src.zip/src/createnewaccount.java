import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JSplitPane;
import javax.swing.JButton;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.UIManager;
import java.awt.Font;

public class createnewaccount extends JFrame
{
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) 
	{
		EventQueue.invokeLater(new Runnable() 
		{
			public void run() 
			{
				try
				{
					createnewaccount frame = new createnewaccount();
					frame.setVisible(true);
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public createnewaccount() 
	{
		getContentPane().setFont(new Font("Times New Roman", getContentPane().getFont().getStyle() & ~Font.BOLD & ~Font.ITALIC, getContentPane().getFont().getSize() + 3));
		getContentPane().setBackground(new Color(128, 128, 128));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 590);
		getContentPane().setLayout(null);
		
		JLabel lblCreateNewAccount = new JLabel("Create New Account");
		lblCreateNewAccount.setBounds(152, 24, 136, 14);
		getContentPane().add(lblCreateNewAccount);
		
		JLabel lblName = new JLabel("First name:");
		lblName.setBounds(33, 54, 100, 14);
		getContentPane().add(lblName);
		
		JLabel lblLastName = new JLabel("Last name:");
		lblLastName.setBounds(33, 93, 100, 14);
		getContentPane().add(lblLastName);
		
		textField = new JTextField();
		textField.setBounds(177, 49, 141, 26);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(177, 87, 141, 26);
		getContentPane().add(textField_1);
		
		JLabel lblGender = new JLabel("Gender");
		lblGender.setBounds(33, 132, 46, 14);
		getContentPane().add(lblGender);
		
		final JRadioButton rdbtnMale = new JRadioButton("Male");
		rdbtnMale.setBounds(177, 128, 56, 23);
		getContentPane().add(rdbtnMale);
		
		final JRadioButton rdbtnFemale = new JRadioButton("Female");
		rdbtnFemale.setBounds(235, 128, 83, 23);
		getContentPane().add(rdbtnFemale);
		
		ButtonGroup bg=new ButtonGroup();
		bg.add(rdbtnMale);
		bg.add(rdbtnFemale);
		
		JLabel lblAge = new JLabel("Age");
		lblAge.setBounds(33, 164, 46, 14);
		getContentPane().add(lblAge);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(177, 158, 141, 26);
		getContentPane().add(textField_2);
		
		JLabel lblDateOfBirth = new JLabel("Date of Birth");
		lblDateOfBirth.setBounds(33, 201, 100, 14);
		getContentPane().add(lblDateOfBirth);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(177, 195, 141, 26);
		getContentPane().add(textField_3);
		
		JLabel lblAccountNo = new JLabel("Account no");
		lblAccountNo.setBounds(33, 243, 100, 14);
		getContentPane().add(lblAccountNo);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(177, 237, 141, 26);
		getContentPane().add(textField_4);
		
		JLabel lblAccountType = new JLabel("Account type");
		lblAccountType.setBounds(33, 281, 100, 14);
		getContentPane().add(lblAccountType);
		
		final JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"current account", "savings account"}));
		comboBox.setBounds(177, 278, 141, 20);
		getContentPane().add(comboBox);
		
		JLabel lblAddress = new JLabel("Address");
		lblAddress.setBounds(33, 316, 61, 14);
		getContentPane().add(lblAddress);
		
		final JTextArea textArea = new JTextArea();
		textArea.setBounds(177, 316, 228, 70);
		getContentPane().add(textArea);
		
		JLabel lblState = new JLabel("State");
		lblState.setBounds(33, 410, 46, 14);
		getContentPane().add(lblState);
		
		final JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"tamil nadu", "kerala", "andhra", ""}));
		comboBox_1.setBounds(89, 407, 105, 20);
		getContentPane().add(comboBox_1);
		
		JLabel lblPincode = new JLabel("pincode");
		lblPincode.setBounds(212, 410, 46, 14);
		getContentPane().add(lblPincode);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(264, 404, 141, 26);
		getContentPane().add(textField_5);
		
		final JButton btnRegister = new JButton("Register");
		btnRegister.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try
				{
					String fname=textField.getText();
					String lname=textField_1.getText();
					String gen="";
					int age=Integer.parseInt(textField_2.getText());
					String dob=textField_3.getText();
					int accno=Integer.parseInt(textField_4.getText());
					String acctype=(String) comboBox.getSelectedItem();
					String ca="";
					String sa="";
					String add=textArea.getText();
					String st=(String) comboBox_1.getSelectedItem();
					String tn="";
					String kl="";
					String ap="";
					int pc=Integer.parseInt(textField_5.getText());
					if(rdbtnMale.isSelected())
					{
					  gen="Male";
					}
					else
					{
						gen="Female";
					}
					
					 String qstr="insert into tb4 values(?,?,?,?,?,?,?,?,?,?)";
						//String qstr1="insert into tb3 values('"+u+"','"+gen+"','"+cource+"','"+ug+"','"+pg+"')";
						Class.forName("org.h2.Driver");
						Connection conn=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test","sa","");
						//Statement stm=conn.createStatement();
						//stm.executeUpdate(qstr1);
						PreparedStatement pt=conn.prepareStatement(qstr);
						pt.setString(1,fname);
						pt.setString(2, lname);
						pt.setString(3,gen);
						pt.setInt(4, age);
						pt.setString(5,dob);
						pt.setInt(6, accno);
						pt.setString(7, acctype);
						pt.setString(8, add);
						pt.setString(9, st);
						pt.setInt(10, pc);
						pt.executeUpdate();
						JOptionPane.showMessageDialog(btnRegister, "User details Inserted..");
				}
				catch(Exception t)
				{
					System.out.println(t);
					System.out.println("hai");
				}
			}
		});
		btnRegister.setBounds(152, 479, 149, 32);
		getContentPane().add(btnRegister);
	}
}
