import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

public class adminaccountdetails extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					adminaccountdetails frame = new adminaccountdetails();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public adminaccountdetails() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblEnterTheAccount = new JLabel("Enter the account no for the curresponding account details ");
		lblEnterTheAccount.setBounds(63, 54, 388, 25);
		contentPane.add(lblEnterTheAccount);
		
		JLabel lblAccNo = new JLabel("Acc no:");
		lblAccNo.setBounds(28, 102, 98, 14);
		contentPane.add(lblAccNo);
		
		textField = new JTextField();
		textField.setBounds(28, 138, 396, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.setBounds(161, 181, 107, 31);
		contentPane.add(btnSubmit);
	}
}
/*public adminhomepage() {
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	setBounds(100, 100, 450, 362);
	contentPane = new JPanel();
	contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
	setContentPane(contentPane);
	contentPane.setLayout(null);
	
	JButton btnNewButton = new JButton("viewdatabase");
	btnNewButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			try
			{
				String qstr="select * from tb4";
				Class.forName("org.h2.Driver");
				Connection conn=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test","sa","");
				Statement stm=conn.createStatement();
				
				ResultSet rs=stm.executeQuery(qstr);
				table.setModel(DbUtils.resultSetToTableModel(rs));
				
			}
			catch(Exception t)
			{
				System.out.println(t);
			}
		}
	});
	btnNewButton.setBounds(119, 22, 150, 23);
	contentPane.add(btnNewButton);
	JScrollPane scrollPane = new JScrollPane();
	scrollPane.setBounds(10, 57, 385, 193);
	contentPane.add(scrollPane);
	
	table = new JTable();
	scrollPane.setViewportView(table);*/
	