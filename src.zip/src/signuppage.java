import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;

public class signuppage extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JPasswordField passwordField;
	private JPasswordField passwordField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					signuppage frame = new signuppage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public signuppage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 286);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblName = new JLabel("name:");
		lblName.setBounds(47, 27, 46, 14);
		contentPane.add(lblName);
		
		textField = new JTextField();
		textField.setBounds(183, 24, 143, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblEmailid = new JLabel("Email-id:");
		lblEmailid.setBounds(47, 66, 80, 14);
		contentPane.add(lblEmailid);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(183, 63, 143, 20);
		contentPane.add(textField_1);
		
		JLabel lblChoosePassword = new JLabel("Choose password:");
		lblChoosePassword.setBounds(47, 104, 114, 14);
		contentPane.add(lblChoosePassword);
		
		JLabel lblConfirmpassword = new JLabel("confirmpassword:");
		lblConfirmpassword.setBounds(47, 140, 114, 14);
		contentPane.add(lblConfirmpassword);
		
		final JButton btnSubmit = new JButton("Submit");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					String name1=textField.getText();
					String email1=textField_1.getText();
				
					//int  a=Integer.parseInt(textField_2.getText());
					String p=passwordField.getText();
					String p1=passwordField_1.getText();
					
				    String qstr="insert into tb5 values(?,?,?,?)";
					//String qstr1="insert into utb2 values('"+name1+"','"+email1+"','"+a+"','"+p+"','"+p1+"')";
					Class.forName("org.h2.Driver");
					Connection conn=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test","sa","");
					//Statement stm=conn.createStatement();
					//stm.executeUpdate(qstr1);
					PreparedStatement pt=conn.prepareStatement(qstr);
					pt.setString(1,name1);
					pt.setString(2, email1);
					//pt.setInt(3, a);
					pt.setString(3,p);
					pt.setString(4,p1);
					pt.executeUpdate();
					JOptionPane.showMessageDialog(btnSubmit, "account created..");
					new createnewaccount().setVisible(true);
				}
				catch(Exception t)
				{
					System.out.println(t);
				}
			}
		});
		btnSubmit.setBounds(156, 181, 89, 23);
		contentPane.add(btnSubmit);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(183, 101, 143, 20);
		contentPane.add(passwordField);
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setBounds(183, 137, 143, 20);
		contentPane.add(passwordField_1);
		
		
	}
}
